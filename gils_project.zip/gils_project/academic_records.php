<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$result = mysqli_query($conn,"
SELECT *
FROM course_registration
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Academic Records</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

body{
margin:0;
padding:30px;
background:#f1f5f9;
font-family:Poppins,sans-serif;
}

.container{
background:white;
padding:25px;
border-radius:20px;
box-shadow:0 5px 20px rgba(0,0,0,.08);
}

h2{
color:#7f1d1d;
margin-bottom:20px;
}

table{
width:100%;
border-collapse:collapse;
}

th{
background:#dc2626;
color:white;
padding:15px;
}

td{
padding:15px;
border-bottom:1px solid #eee;
}

tr:hover{
background:#fef2f2;
}
/**زر عودة لداشبورد */
.back-btn{
display:inline-block;
margin-bottom:20px;
padding:12px 18px;
background:#dc2626;
color:white;
text-decoration:none;
border-radius:10px;
font-weight:600;
transition:.3s;
}

.back-btn:hover{
background:#b91c1c;
}
/**========================== */
.course{
background:#dc2626;
color:white;
padding:5px 10px;
border-radius:20px;
font-size:13px;
}

</style>

</head>

<body>

<div class="container">
<a href="admissions_dashboard.php" class="back-btn">
<i class="fa-solid fa-arrow-left"></i>
Back to Dashboard
</a>

<h2>
<i class="fa-solid fa-database"></i>
Academic Records
</h2>

<table>

<tr>
<th>Student</th>
<th>Course</th>
<th>Registration Date</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?php echo $row['student_name']; ?>
</td>

<td>
<span class="course">
<?php echo $row['course_name']; ?>
</span>
</td>

<td>
<?php echo $row['registration_date']; ?>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>