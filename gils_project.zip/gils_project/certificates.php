<?php

session_start();
if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

include "db.php";

$student_id = $_SESSION['user_id'];

$message = "";


 
?>

<!DOCTYPE html>
<html>

<head>

<meta charset="UTF-8">

<title>Training Certificates</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

body{
    margin:0;
    background:#eef2f7;
    font-family:Poppins,sans-serif;
}

.container{
    width:75%;
    margin:40px auto;
}

.card{
    background:white;
    padding:30px;
    border-radius:15px;
    box-shadow:0 2px 10px rgba(0,0,0,.1);
}

h1{
    color:#0b1f4d;
}

input{
    width:100%;
    padding:12px;
    margin-top:8px;
    margin-bottom:15px;
    border:1px solid #ccc;
    border-radius:8px;
}

.btn{
    background:#25a9e0;
    color:white;
    border:none;
    padding:12px 25px;
    border-radius:8px;
    cursor:pointer;
}

.back-btn{
    text-decoration:none;
    background:#0b1f4d;
    color:white;
    padding:10px 20px;
    border-radius:8px;
}

.success{
    background:#d4edda;
    color:#155724;
    padding:10px;
    border-radius:8px;
    margin-bottom:15px;
}

table{
    width:100%;
    margin-top:30px;
    border-collapse:collapse;
}

table th,
table td{
    border:1px solid #ddd;
    padding:10px;
}

</style>

</head>

<body>

<div class="container">

<a href="student_dashboard.php" class="back-btn">
Back To Dashboard
</a>

<div class="card">

<h1>Training Certificates</h1>

<?php
if(!empty($message)){
echo "<div class='success'>$message</div>";
}
?>
<hr>


<h2>My Certificates</h2>

<table>

<tr>
<th>Course</th>
<th>Provider</th>
<th>Certificate</th>
</tr>

<?php

$result = mysqli_query($conn,"
SELECT *
FROM certificates
WHERE student_id='$student_id'
ORDER BY id DESC
");

while($row = mysqli_fetch_assoc($result)){

?>

<tr>

<td><?php echo $row['course_name']; ?></td>

<td><?php echo $row['provider']; ?></td>

<td>

<a href="uploads/<?php echo $row['certificate_file']; ?>" target="_blank">

View File

</a>

</td>

</tr>

<?php } ?>

</table>

</div>

</div>

</body>

</html>