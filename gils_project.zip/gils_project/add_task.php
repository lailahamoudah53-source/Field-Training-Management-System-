<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['name'];

/* جلب بيانات الطالب (المؤسسة) من training_requests */
$get = mysqli_query($conn,"
SELECT company_name 
FROM training_requests 
WHERE student_id='$user_id' 
AND status='Approved'
LIMIT 1
");

$data = mysqli_fetch_assoc($get);
$company_name = $data['company_name'] ?? '';

/* حفظ المهمة */
if(isset($_POST['save_task'])){

    $task = mysqli_real_escape_string($conn, $_POST['task']);
    $date = date('Y-m-d');

    /* منع التكرار بنفس اليوم */
    $check = mysqli_query($conn,"
        SELECT * FROM training_tasks 
        WHERE student_id='$user_id' 
        AND task_date='$date'
    ");

    if(mysqli_num_rows($check) > 0){
        echo "<script>alert('لقد تم تسجيل مهمة اليوم مسبقاً');</script>";
    } else {

        mysqli_query($conn,"
            INSERT INTO training_tasks
            (student_id, student_name, company_name, task_date, task_text)
            VALUES
            ('$user_id','$username','$company_name','$date','$task')
        ");

        echo "<script>alert('تم حفظ المهمة بنجاح');</script>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Training Tasks</title>

<style>
body{
    font-family:Arial;
    background:#f1f5f9;
    padding:30px;
}

.container{
    background:white;
    padding:25px;
    border-radius:12px;
    width:60%;
    margin:auto;
    box-shadow:0 5px 15px rgba(0,0,0,0.1);
}

textarea{
    width:100%;
    height:120px;
    padding:10px;
    border-radius:10px;
}

button{
    padding:12px;
    background:#10b981;
    color:white;
    border:none;
    width:100%;
    margin-top:10px;
    border-radius:10px;
}
/**زر عودة لداشبورد */
.back-btn{
display:inline-block;
margin-bottom:20px;
padding:12px 18px;
background:green;
color:white;
text-decoration:none;
border-radius:10px;
font-weight:600;
transition:.3s;
}

.back-btn:hover{
background:#b91c1c;
}
/**========================== */
</style>
</head>

<body>

<div class="container">
    <a href="institution_dashboard.php" class="back-btn">
<i class="fa-solid fa-arrow-left"></i>
Back to Dashboard
</a>

<h2>توثيق المهام اليومية</h2>

<form method="POST">

<textarea name="task" placeholder="اكتب المهمة التي قمت بها اليوم..." required></textarea>

<button type="submit" name="save_task">
حفظ المهمة
</button>

</form>

</div>

</body>
</html>