document
.getElementById("loginForm")

.addEventListener("submit", function(event){
event.preventDefault();
let email = document.getElementById("email").value;
let password = document.getElementById("password").value;
let role = document.getElementById("role").value;
    if(email === "" || password === "" || role === ""){
alert("Please fill all fields");

    }

    else{
alert("Login Successful");

    }
});
