<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$result = mysqli_query($conn, "SELECT * FROM official_letters ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Official Letters</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:Poppins,sans-serif;
}

body{
    background:#f4f7fc;
    display:flex;
}

/* --------------------------------------
   الشريط الجانبي (نفس تنسيق باقي الصفحات)
-------------------------------------- */
.sidebar{
    width:250px;
    height:100vh;
    background:#0f172a;
    padding:25px;
    position:fixed;
}

.sidebar h2{
    color:#38bdf8;
    text-align:center;
    margin-bottom:35px;
}

.sidebar ul{
    list-style:none;
}

.sidebar ul li{
    margin-bottom:15px;
}

.sidebar ul li a{
    display:block;
    padding:12px;
    color:white;
    text-decoration:none;
    border-radius:10px;
    transition:.3s;
}

.sidebar ul li a:hover,
.sidebar ul li a.active{
    background:#1e293b;
}

/* --------------------------------------
   المحتوى الرئيسي
-------------------------------------- */
.main{
    margin-left:250px;
    padding:40px;
    width:100%;
}

.page-title{
    margin-bottom:30px;
    color:#0f172a;
    font-size:28px;
    display:flex;
    align-items:center;
    gap:12px;
}

.page-title i{
    color:#38bdf8;
}

/* --------------------------------------
   بطاقة الخطابات
-------------------------------------- */
.card{
    background:white;
    padding:30px;
    border-radius:20px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
    margin-bottom:20px;
    border-left:5px solid #38bdf8;
    transition:.3s;
}

.card:hover{
    transform:translateY(-3px);
    box-shadow:0 8px 25px rgba(0,0,0,.12);
}

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:15px;
    padding-bottom:15px;
    border-bottom:1px solid #eee;
}

.company-name{
    font-size:20px;
    color:#0f172a;
    font-weight:bold;
    display:flex;
    align-items:center;
    gap:10px;
}

.company-name i{
    color:#38bdf8;
}

.date{
    color:#64748b;
    font-size:13px;
    display:flex;
    align-items:center;
    gap:6px;
}

.letter-text{
    color:#334155;
    line-height:1.8;
    font-size:15px;
    padding:15px;
    background:#f8fafc;
    border-radius:10px;
    margin-top:10px;
}

/* --------------------------------------
   حالة عدم وجود خطابات
-------------------------------------- */
.empty-state{
    text-align:center;
    padding:60px 20px;
    background:white;
    border-radius:20px;
    box-shadow:0 5px 15px rgba(0,0,0,.08);
}

.empty-state i{
    font-size:60px;
    color:#cbd5e1;
    margin-bottom:20px;
}

.empty-state p{
    color:#64748b;
    font-size:16px;
}

/* --------------------------------------
   تصميم متجاوب
-------------------------------------- */
@media(max-width:768px){
    .sidebar{
        width:100%;
        height:auto;
        position:relative;
    }
    .main{
        margin-left:0;
        padding:20px;
    }
    .card-header{
        flex-direction:column;
        align-items:flex-start;
        gap:10px;
    }
}
</style>
</head>

<body>

<!-- الشريط الجانبي -->
<div class="sidebar">
    <h2>FTS System</h2>
    <ul>
        <li>
            <a href="supervisor_dashboard.php">
                <i class="fa-solid fa-house"></i> Dashboard
            </a>
        </li>
        <li>
            <a href="supervisor_profile.php">
                <i class="fa-solid fa-user"></i> Profile
            </a>
        </li>
        <li>
            <a href="registration_requests.php">
                <i class="fa-solid fa-clipboard-list"></i> Training Requests
            </a>
        </li>
        <li>
            <a href="official_letters.php" class="active">
                <i class="fa-solid fa-envelope-open-text"></i> Official Letters
            </a>
        </li>
        <li>
            <a href="login.php">
                <i class="fa-solid fa-right-from-bracket"></i> Logout
            </a>
        </li>
    </ul>
</div>

<!-- المحتوى الرئيسي -->
<div class="main">

    <!-- عنوان الصفحة -->
    <h1 class="page-title">
        <i class="fa-solid fa-envelope-open-text"></i>
        Official Letters
    </h1>

    <!-- عرض الخطابات -->
    <?php if(mysqli_num_rows($result) > 0): ?>

        <?php while($row = mysqli_fetch_assoc($result)){ ?>
            <div class="card">
                <div class="card-header">
                    <div class="company-name">
                        <i class="fa-solid fa-building"></i>
                        <?php echo htmlspecialchars($row['company_name']); ?>
                    </div>
                    <div class="date">
                        <i class="fa-regular fa-calendar"></i>
                        <?php echo date('d M Y', strtotime($row['created_at'])); ?>
                    </div>
                </div>
                <div class="letter-text">
                    <?php echo nl2br(htmlspecialchars($row['letter_text'])); ?>
                </div>
            </div>
        <?php } ?>

    <?php else: ?>
        <!-- رسالة عند عدم وجود خطابات -->
        <div class="empty-state">
            <i class="fa-regular fa-envelope-open"></i>
            <p>No official letters available</p>
        </div>
    <?php endif; ?>

</div>

</body>
</html>