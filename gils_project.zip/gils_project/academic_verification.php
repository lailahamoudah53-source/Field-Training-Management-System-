<?php
session_start();
include "db.php";

if(!isset($_SESSION['user_id'])){
    header("Location: login.php");
    exit();
}

$result = mysqli_query($conn,"
SELECT *
FROM academic_verification
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Academic Verification</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

body{
margin:0;
padding:30px;
background:#f1f5f9;
font-family:Poppins,sans-serif;
}

.container{
background:white;
padding:25px;
border-radius:20px;
box-shadow:0 5px 20px rgba(0,0,0,.08);
}

.back-btn{
display:inline-block;
margin-bottom:20px;
padding:12px 18px;
background:#7f1d1d;
color:white;
text-decoration:none;
border-radius:10px;
}

.back-btn:hover{
background:#991b1b;
}

h2{
color:#7f1d1d;
margin-bottom:20px;
}

table{
width:100%;
border-collapse:collapse;
}

th{
background:#dc2626;
color:white;
padding:15px;
}

td{
padding:15px;
border-bottom:1px solid #eee;
}

tr:hover{
background:#fef2f2;
}

.status{
background:#16a34a;
color:white;
padding:6px 12px;
border-radius:20px;
font-size:13px;
}

</style>

</head>

<body>

<div class="container">

<a href="admissions_dashboard.php" class="back-btn">
<i class="fa fa-arrow-left"></i>
Back to Dashboard
</a>

<h2>
<i class="fa-solid fa-user-check"></i>
Academic Verification
</h2>

<table>

<tr>
<th>Student</th>
<th>GPA</th>
<th>Completed Hours</th>
<th>Status</th>
</tr>

<?php while($row=mysqli_fetch_assoc($result)){ ?>

<tr>

<td>
<?php echo $row['student_name']; ?>
</td>

<td>
<?php echo $row['gpa']; ?>
</td>

<td>
<?php echo $row['completed_hours']; ?>
</td>

<td>
<span class="status">
<?php echo $row['academic_status']; ?>
</span>
</td>

</tr>

<?php } ?>

</table>

</div>

</body>
</html>